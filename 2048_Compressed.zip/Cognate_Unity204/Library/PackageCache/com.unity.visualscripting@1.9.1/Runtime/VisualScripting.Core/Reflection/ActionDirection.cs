namespace Unity.VisualScripting
{
    public enum ActionDirection
    {
        Any = 0,
        Get = 1,
        Set = 2
    }
}
