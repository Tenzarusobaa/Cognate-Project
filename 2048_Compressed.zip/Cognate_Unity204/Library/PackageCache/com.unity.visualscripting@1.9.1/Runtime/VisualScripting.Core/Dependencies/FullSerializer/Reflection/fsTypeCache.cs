namespace Unity.VisualScripting.FullSerializer
{
    /// <summary>
    /// Caches type name to type lookups. Type lookups occur in all loaded
    /// assemblies.
    /// </summary>
    public static class fsTypeCache
    {
        // Moved / converted to RuntimeCodebase
    }
}
